---
name: my-skill
description: A description of what this skill does and when to use it.
metadata:
  author: k-nagamatsu
---