# AI-DLC 適応型ワークフローの概要

**目的**: AIモデルおよび開発者がワークフロー全体の構造を理解するための技術リファレンス。

**注**: 同様の内容が welcome-message.md（ユーザー向けウェルカムメッセージ）および README.md（ドキュメント）にも記載されています。この重複は意図的なものです。各ファイルには異なる目的があります：
- **本ファイル**：AIモデルのコンテキスト読み込みに関する、Mermaid図を用いた詳細な技術リファレンス
- **welcome-message.md**：ASCII図を用いたユーザー向けのウェルカムメッセージ
- **README.md**：リポジトリ向けの、人間が読みやすいドキュメント

## 3つのフェーズからなるライフサイクル：
• **INCEPTION PHASE(構想フェーズ)**: 計画とアーキテクチャ（ワークスペースの検出 + 条件付きフェーズ + ワークフローの計画）
• **CONSTRUCTION PHASE(構築フェーズ)**: 設計、実装、ビルド、テスト（ユニットごとの設計 + コード生成 + ビルドとテスト）
• **OPERATIONS PHASE(運用フェーズ)**: 将来のデプロイおよび監視ワークフローのためのプレースホルダー

## 適応型ワークフロー：
• **ワークスペースの検出**（常に） → **リバースエンジニアリング**（既存システムのみ） → **要件分析**（常に、適応的な深度） → **条件付きフェーズ**（必要に応じて） → **ワークフロー計画**（常に） → **コード生成**（常に、ユニット単位） → **ビルドとテスト**（常に）

## 仕組み：
• **AIが**リクエスト、ワークスペース、および複雑さを分析し、必要なステージを判断します
• **常に実行されるステージ**：ワークスペース検出、要件分析（適応型深度）、ワークフロー計画、コード生成（ユニット単位）、ビルドおよびテスト
• **その他のすべてのステージは条件付きで実行されます**：リバースエンジニアリング、ユーザーストーリー、アプリケーション設計、ユニット生成、ユニットごとの設計ステージ（機能設計、非機能要件、非機能設計、インフラ設計）
• **固定された順序はありません**：ステージは、特定のタスクにとって合理的な順序で実行されます

## チームの役割：
• 専用の質問ファイル内の質問に、選択肢（A、B、C、D、E）を記載した [Answer]: タグを使用して**回答**してください
• **選択肢Eの利用**：提示された選択肢に該当するものがない場合は、「その他」を選択し、独自の回答を記述してください
• **チームで協力**して、各フェーズを進める前に内容を確認・承認してください
• **必要に応じて**、アーキテクチャのアプローチをチームで決定してください
• **重要**：これはチームでの取り組みです。各フェーズにおいて、関連するステークホルダーを巻き込んでください

## AI-DLCの3段階ワークフロー：

```mermaid
flowchart TD
    Start(["User Request"])
    
    subgraph INCEPTION["🔵 INCEPTION PHASE"]
        WD["Workspace Detection<br/><b>ALWAYS</b>"]
        RE["Reverse Engineering<br/><b>CONDITIONAL</b>"]
        RA["Requirements Analysis<br/><b>ALWAYS</b>"]
        Stories["User Stories<br/><b>CONDITIONAL</b>"]
        WP["Workflow Planning<br/><b>ALWAYS</b>"]
        AppDesign["Application Design<br/><b>CONDITIONAL</b>"]
        UnitsG["Units Generation<br/><b>CONDITIONAL</b>"]
    end
    
    subgraph CONSTRUCTION["🟢 CONSTRUCTION PHASE"]
        FD["Functional Design<br/><b>CONDITIONAL</b>"]
        NFRA["NFR Requirements<br/><b>CONDITIONAL</b>"]
        NFRD["NFR Design<br/><b>CONDITIONAL</b>"]
        ID["Infrastructure Design<br/><b>CONDITIONAL</b>"]
        CG["Code Generation<br/><b>ALWAYS</b>"]
        BT["Build and Test<br/><b>ALWAYS</b>"]
    end
    
    subgraph OPERATIONS["🟡 OPERATIONS PHASE"]
        OPS["Operations<br/><b>PLACEHOLDER</b>"]
    end
    
    Start --> WD
    WD -.-> RE
    WD --> RA
    RE --> RA
    
    RA -.-> Stories
    RA --> WP
    Stories --> WP
    
    WP -.-> AppDesign
    WP -.-> UnitsG
    AppDesign -.-> UnitsG
    UnitsG --> FD
    FD -.-> NFRA
    NFRA -.-> NFRD
    NFRD -.-> ID
    
    WP --> CG
    FD --> CG
    NFRA --> CG
    NFRD --> CG
    ID --> CG
    CG -.->|Next Unit| FD
    CG --> BT
    BT -.-> OPS
    BT --> End(["Complete"])
    
    style WD fill:#4CAF50,stroke:#1B5E20,stroke-width:3px,color:#fff
    style RA fill:#4CAF50,stroke:#1B5E20,stroke-width:3px,color:#fff
    style WP fill:#4CAF50,stroke:#1B5E20,stroke-width:3px,color:#fff

    style CG fill:#4CAF50,stroke:#1B5E20,stroke-width:3px,color:#fff
    style BT fill:#4CAF50,stroke:#1B5E20,stroke-width:3px,color:#fff
    style OPS fill:#BDBDBD,stroke:#424242,stroke-width:2px,stroke-dasharray: 5 5,color:#000
    style RE fill:#FFA726,stroke:#E65100,stroke-width:3px,stroke-dasharray: 5 5,color:#000
    style Stories fill:#FFA726,stroke:#E65100,stroke-width:3px,stroke-dasharray: 5 5,color:#000
    style AppDesign fill:#FFA726,stroke:#E65100,stroke-width:3px,stroke-dasharray: 5 5,color:#000

    style UnitsG fill:#FFA726,stroke:#E65100,stroke-width:3px,stroke-dasharray: 5 5,color:#000
    style FD fill:#FFA726,stroke:#E65100,stroke-width:3px,stroke-dasharray: 5 5,color:#000
    style NFRA fill:#FFA726,stroke:#E65100,stroke-width:3px,stroke-dasharray: 5 5,color:#000
    style NFRD fill:#FFA726,stroke:#E65100,stroke-width:3px,stroke-dasharray: 5 5,color:#000
    style ID fill:#FFA726,stroke:#E65100,stroke-width:3px,stroke-dasharray: 5 5,color:#000
    style INCEPTION fill:#BBDEFB,stroke:#1565C0,stroke-width:3px, color:#000
    style CONSTRUCTION fill:#C8E6C9,stroke:#2E7D32,stroke-width:3px, color:#000
    style OPERATIONS fill:#FFF59D,stroke:#F57F17,stroke-width:3px, color:#000
    style Start fill:#CE93D8,stroke:#6A1B9A,stroke-width:3px,color:#000
    style End fill:#CE93D8,stroke:#6A1B9A,stroke-width:3px,color:#000
    
    linkStyle default stroke:#333,stroke-width:2px
```

**各フェーズの説明：**

**🔵 構想フェーズ** - 計画とアーキテクチャ
- ワークスペースの検出：ワークスペースの状態とプロジェクトの種類を分析する（常に実施）
- リバースエンジニアリング：既存のコードベースを分析する（条件付き - ブラウンフィールドのみ）
- 要件分析：要件を収集・検証する（常に実施 - 適応的な詳細度）
- ユーザーストーリー：ユーザーストーリーとペルソナを作成する（条件付き）
- ワークフロー計画：実行計画を作成する（常に）
- アプリケーション設計：高レベルのコンポーネントの特定とサービス層の設計（条件付き）
- 作業単位の生成：作業単位に分解する（条件付き）

**🟢 構築フェーズ** - 設計、実装、ビルド、テスト
- 機能設計：ユニットごとの詳細なビジネスロジック設計（条件付き、ユニットごと）
- NFR要件：NFRを特定し、技術スタックを選択（条件付き、ユニットごと）
- NFR設計：NFRパターンおよび論理コンポーネントを組み込む（条件付き、ユニットごと）
- インフラ設計：実際のインフラサービスへのマッピング（条件付き、ユニットごと）
- コード生成：パート1 - 計画、パート2 - 生成を用いてコードを生成する（常に、ユニットごと）
- ビルドおよびテスト：すべてのユニットをビルドし、包括的なテストを実行する（常に）

**🟡 運用フェーズ** - 仮置き
- 運用：今後のデプロイおよび監視ワークフローのための仮置き（仮置き）

**基本原則：**
- フェーズは、付加価値をもたらす場合にのみ実行される
- 各フェーズは個別に評価される
- 「INCEPTION」フェーズでは「何」と「なぜ」に焦点を当てる
- 「CONSTRUCTION」フェーズでは「どのように」に加え、「構築とテスト」に焦点を当てる
- 「OPERATIONS」フェーズは、将来の拡張に向けた予備的な枠組みである
- 単純な変更については、条件付きで「INCEPTION」フェーズを省略できる
- 複雑な変更については、「INCEPTION」および「CONSTRUCTION」フェーズを完全に実施する